
import { v4 as uuidv4 } from 'uuid';

// Generate a unique public ID for the user
export const generatePublicId = (): string => {
  return uuidv4();
};

// Generate a URL for the QR code
export const generateQRCodeUrl = (publicId: string): string => {
  // In production, this would be your actual domain
  const baseUrl = window.location.origin;
  return `${baseUrl}/patient/${publicId}`;
};

// Function to download QR code as image
export const downloadQRCode = (): void => {
  const canvas = document.getElementById('qr-code') as HTMLCanvasElement;
  if (canvas) {
    const pngUrl = canvas
      .toDataURL('image/png')
      .replace('image/png', 'image/octet-stream');
    
    const downloadLink = document.createElement('a');
    downloadLink.href = pngUrl;
    downloadLink.download = 'medical-qr-code.png';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  }
};
