
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  User 
} from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { getAnalytics } from 'firebase/analytics';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD9toW0UMAFpshSi1pR5gifOFCnM0sXScw",
  authDomain: "emergency-healthcare-865bc.firebaseapp.com",
  projectId: "emergency-healthcare-865bc",
  storageBucket: "emergency-healthcare-865bc.appspot.com",
  messagingSenderId: "466634886416",
  appId: "1:466634886416:web:3852367d4aefa9dc89e995",
  measurementId: "G-LF9W7Z70LD"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const analytics = getAnalytics(app);
const googleProvider = new GoogleAuthProvider();

// Google Authentication
export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    
    // Check if user profile exists, if not create one
    const userProfile = await getUserProfile(user.uid);
    if (!userProfile) {
      await createUserProfile(user.uid, {
        fullName: user.displayName || '',
        email: user.email || '',
        profileCompleted: false,
      });
    }
    
    return user;
  } catch (error) {
    console.error('Error signing in with Google:', error);
    throw error;
  }
};

export const logoutUser = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Error logging out:', error);
    throw error;
  }
};

// Firestore functions
export const createUserProfile = async (uid: string, userData: any) => {
  try {
    await setDoc(doc(db, 'users', uid), {
      ...userData,
      createdAt: new Date(),
    });
  } catch (error) {
    console.error('Error creating user profile:', error);
    throw error;
  }
};

export const getUserProfile = async (uid: string) => {
  try {
    const docRef = doc(db, 'users', uid);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return docSnap.data();
    } else {
      console.log('No such document!');
      return null;
    }
  } catch (error) {
    console.error('Error getting user profile:', error);
    throw error;
  }
};

export const createPublicProfile = async (publicId: string, publicData: any) => {
  try {
    await setDoc(doc(db, 'public_profiles', publicId), {
      ...publicData,
      createdAt: new Date(),
    });
    return publicId;
  } catch (error) {
    console.error('Error creating public profile:', error);
    throw error;
  }
};

export const getPublicProfile = async (publicId: string) => {
  try {
    const docRef = doc(db, 'public_profiles', publicId);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return docSnap.data();
    } else {
      console.log('No such public profile!');
      return null;
    }
  } catch (error) {
    console.error('Error getting public profile:', error);
    throw error;
  }
};

export const updateUserThemePreference = async (uid: string, isDarkMode: boolean) => {
  try {
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, { isDarkMode }, { merge: true });
    return true;
  } catch (error) {
    console.error('Error updating theme preference:', error);
    throw error;
  }
};

export const getUserThemePreference = async (uid: string) => {
  try {
    const userProfile = await getUserProfile(uid);
    return userProfile?.isDarkMode;
  } catch (error) {
    console.error('Error getting theme preference:', error);
    return null;
  }
};

// Constants for collections
export const COLLECTIONS = {
  USERS: 'users',
  PUBLIC_PROFILES: 'public_profiles',
};

// Export Firebase instances
export { auth, db };
