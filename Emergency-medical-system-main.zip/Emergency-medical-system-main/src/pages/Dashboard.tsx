
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Navbar from '../components/Navbar';
import { getUserProfile } from '../utils/firebase';
import { Edit, QrCode, AlertTriangle, ClipboardCheck } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      if (currentUser) {
        try {
          const profileData = await getUserProfile(currentUser.uid);
          setProfile(profileData);
        } catch (error) {
          console.error('Error fetching profile:', error);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchProfile();
  }, [currentUser]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <div className="rounded-md h-12 w-12 border-4 border-t-medical-primary border-r-transparent border-b-transparent border-l-transparent animate-spin"></div>
        </div>
      </div>
    );
  }

  const profileComplete = profile?.profileCompleted;
  const hasQrCode = profile?.publicId;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-gray-800">Welcome, {profile?.fullName || 'User'}</h2>
              <p className="text-gray-600 mt-1">Manage your medical profile and QR code</p>
            </div>
            
            {!profileComplete && (
              <div className="flex items-center mt-4 md:mt-0 bg-amber-50 text-amber-800 px-4 py-2 rounded-md">
                <AlertTriangle className="h-5 w-5 mr-2" />
                <span className="text-sm">Your medical profile is incomplete</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center mb-4">
              <ClipboardCheck className="h-6 w-6 text-medical-primary mr-2" />
              <h3 className="text-xl font-semibold text-gray-800">Medical Profile</h3>
            </div>
            
            {profileComplete ? (
              <div>
                <div className="bg-green-50 text-green-800 px-4 py-2 rounded-md mb-4 inline-flex items-center">
                  <ClipboardCheck className="h-5 w-5 mr-2" />
                  <span>Profile Complete</span>
                </div>
                
                <p className="text-gray-600 mb-4">
                  Your medical profile is complete and ready for emergencies. You can edit it at any time.
                </p>
                
                <Link to="/profile-form" className="inline-flex items-center text-medical-primary hover:text-medical-secondary">
                  <Edit className="h-4 w-4 mr-1" />
                  <span>Edit Profile</span>
                </Link>
              </div>
            ) : (
              <div>
                <p className="text-gray-600 mb-4">
                  Complete your medical profile to generate your emergency QR code.
                </p>
                
                <Link to="/profile-form" className="bg-medical-primary hover:bg-medical-secondary text-white font-medium py-2 px-4 rounded-md transition duration-300 inline-flex items-center">
                  <Edit className="h-4 w-4 mr-2" />
                  <span>{profile?.profileStarted ? 'Complete Profile' : 'Create Profile'}</span>
                </Link>
              </div>
            )}
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center mb-4">
              <QrCode className="h-6 w-6 text-medical-primary mr-2" />
              <h3 className="text-xl font-semibold text-gray-800">Emergency QR Code</h3>
            </div>
            
            {hasQrCode ? (
              <div>
                <div className="bg-green-50 text-green-800 px-4 py-2 rounded-md mb-4 inline-flex items-center">
                  <QrCode className="h-5 w-5 mr-2" />
                  <span>QR Code Active</span>
                </div>
                
                <p className="text-gray-600 mb-4">
                  Your emergency QR code is ready. You can view, download, or share it.
                </p>
                
                <Link to="/qr-code" className="bg-medical-primary hover:bg-medical-secondary text-white font-medium py-2 px-4 rounded-md transition duration-300 inline-flex items-center">
                  <QrCode className="h-4 w-4 mr-2" />
                  <span>View QR Code</span>
                </Link>
              </div>
            ) : (
              <div>
                {profileComplete ? (
                  <div>
                    <p className="text-gray-600 mb-4">
                      Your profile is complete. Generate your emergency QR code now.
                    </p>
                    
                    <Link to="/qr-code" className="bg-medical-primary hover:bg-medical-secondary text-white font-medium py-2 px-4 rounded-md transition duration-300 inline-flex items-center">
                      <QrCode className="h-4 w-4 mr-2" />
                      <span>Generate QR Code</span>
                    </Link>
                  </div>
                ) : (
                  <div>
                    <p className="text-gray-600 mb-4">
                      Complete your medical profile first to generate your QR code.
                    </p>
                    
                    <button disabled className="bg-gray-200 text-gray-500 font-medium py-2 px-4 rounded-md inline-flex items-center cursor-not-allowed">
                      <QrCode className="h-4 w-4 mr-2" />
                      <span>Generate QR Code</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
