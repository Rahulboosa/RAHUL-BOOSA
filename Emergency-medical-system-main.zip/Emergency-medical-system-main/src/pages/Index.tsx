
import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { Heart, QrCode, Shield, Clock } from 'lucide-react';

const Index: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-medical-light to-white py-16 md:py-24">
          <div className="container mx-auto px-6 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
              Critical Health Information When It Matters Most
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Create your personal medical profile and generate a QR code that first responders can scan to access vital health information in emergencies.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/register" className="bg-medical-primary hover:bg-medical-secondary text-white font-bold py-3 px-8 rounded-lg transition duration-300 shadow-md">
                Create Your MediQR Profile
              </Link>
              <Link to="/login" className="bg-white hover:bg-gray-100 text-medical-primary font-bold py-3 px-8 rounded-lg border border-medical-primary transition duration-300 shadow-md">
                Sign In
              </Link>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-6">
            <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">How MediQR Works</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-medical-light rounded-lg p-6 text-center shadow-md">
                <div className="w-16 h-16 bg-medical-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <QrCode className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-gray-800">Create Your Profile</h3>
                <p className="text-gray-600">Enter your essential medical information securely in our system.</p>
              </div>
              
              <div className="bg-medical-light rounded-lg p-6 text-center shadow-md">
                <div className="w-16 h-16 bg-medical-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-gray-800">Generate QR Code</h3>
                <p className="text-gray-600">Download your unique QR code to print or save on your phone.</p>
              </div>
              
              <div className="bg-medical-light rounded-lg p-6 text-center shadow-md">
                <div className="w-16 h-16 bg-medical-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-gray-800">Emergency Access</h3>
                <p className="text-gray-600">Medical professionals can scan your code to instantly access critical information.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-6">
            <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Why Choose MediQR</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="flex space-x-4">
                <div className="flex-shrink-0">
                  <Shield className="h-6 w-6 text-medical-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-gray-800">Privacy Protected</h3>
                  <p className="text-gray-600">You control exactly what information is publicly accessible. Your private data remains secure.</p>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <div className="flex-shrink-0">
                  <Clock className="h-6 w-6 text-medical-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-gray-800">Quick Access</h3>
                  <p className="text-gray-600">Save precious time in emergencies when medical professionals need your information fast.</p>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <div className="flex-shrink-0">
                  <Heart className="h-6 w-6 text-medical-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-gray-800">Life-Saving Information</h3>
                  <p className="text-gray-600">Share allergies, medications, conditions and contacts that could be critical in an emergency.</p>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <div className="flex-shrink-0">
                  <QrCode className="h-6 w-6 text-medical-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2 text-gray-800">Universal Technology</h3>
                  <p className="text-gray-600">QR codes can be scanned by any smartphone camera - no special app required for medical personnel.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-medical-primary">
          <div className="container mx-auto px-6 text-center">
            <h2 className="text-3xl font-bold text-white mb-6">Prepare for the Unexpected Today</h2>
            <p className="text-white text-xl mb-8 max-w-3xl mx-auto">
              Don't wait for an emergency to wish you had better prepared. Create your MediQR profile now.
            </p>
            <Link to="/register" className="bg-white hover:bg-gray-100 text-medical-primary font-bold py-3 px-8 rounded-lg transition duration-300 shadow-md inline-block">
              Get Started - It's Free
            </Link>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <Heart className="h-6 w-6 text-medical-primary mr-2" />
              <span className="text-xl font-bold">MediQR</span>
            </div>
            <div className="text-sm text-gray-400">
              © {new Date().getFullYear()} MediQR. All rights reserved. Privacy and security first.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
