
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { getPublicProfile } from '../utils/firebase';
import { useTheme } from '../context/ThemeContext';
import { 
  AlertCircle, 
  Heart, 
  Clock, 
  Calendar, 
  DropletIcon, 
  PillIcon, 
  AlertTriangleIcon, 
  XCircle,
  Mail,
  Phone,
  User,
  Syringe,
  Brain,
  Activity,
  BadgeCheck
} from 'lucide-react';

const PublicProfile: React.FC = () => {
  const { publicId } = useParams<{ publicId: string }>();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { isDarkMode } = useTheme();

  useEffect(() => {
    const fetchPublicProfile = async () => {
      if (publicId) {
        try {
          const profileData = await getPublicProfile(publicId);
          if (profileData) {
            setProfile(profileData);
          } else {
            setError('Profile not found');
          }
        } catch (error) {
          console.error('Error fetching public profile:', error);
          setError('Failed to load profile data');
        } finally {
          setLoading(false);
        }
      }
    };

    fetchPublicProfile();
  }, [publicId]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="rounded-md h-12 w-12 border-4 border-t-medical-primary border-r-transparent border-b-transparent border-l-transparent animate-spin"></div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 p-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 max-w-md w-full text-center">
          <div className="mb-4">
            <XCircle className="h-16 w-16 text-red-500 mx-auto" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-2">Profile Not Found</h1>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            The emergency medical profile you're looking for does not exist or may have been removed.
          </p>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Error: {error || 'Profile not available'}
          </div>
        </div>
      </div>
    );
  }

  // Calculate age from date of birth
  const calculateAge = (dateOfBirth: string) => {
    const birthDate = new Date(dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  };

  const age = profile.age || (profile.dateOfBirth ? calculateAge(profile.dateOfBirth) : null);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8 px-4 transition-colors duration-200">
      <div className="max-w-md mx-auto">
        <div className="bg-medical-primary dark:bg-medical-secondary text-white py-4 px-6 rounded-t-lg text-center shadow-md">
          <div className="flex justify-center mb-2">
            <Heart className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-bold">Emergency Medical Information</h1>
          <p className="text-sm mt-1 opacity-90">For healthcare professionals only</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-b-lg shadow-md overflow-hidden">
          {/* Basic Info */}
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">Patient Information</h2>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Name</p>
                <p className="font-semibold text-gray-800 dark:text-gray-200">{profile.name}</p>
              </div>
              
              {age !== null && (
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Age</p>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 text-medical-primary dark:text-medical-accent mr-1" />
                    <p className="font-semibold text-gray-800 dark:text-gray-200">{age} years</p>
                  </div>
                </div>
              )}
              
              {profile.bloodGroup && (
                <div className="col-span-2">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Blood Type</p>
                  <div className="flex items-center">
                    <DropletIcon className="h-4 w-4 text-red-500 mr-1" />
                    <p className="font-semibold text-gray-800 dark:text-gray-200">{profile.bloodGroup}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Contact Information */}
          {(profile.email || profile.phoneNumber) && (
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">Contact Information</h2>
              
              <div className="grid grid-cols-1 gap-4">
                {profile.email && (
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Email</p>
                    <div className="flex items-center">
                      <Mail className="h-4 w-4 text-medical-primary dark:text-medical-accent mr-1" />
                      <p className="font-semibold text-gray-800 dark:text-gray-200">{profile.email}</p>
                    </div>
                  </div>
                )}
                
                {profile.phoneNumber && (
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Phone</p>
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 text-medical-primary dark:text-medical-accent mr-1" />
                      <p className="font-semibold text-gray-800 dark:text-gray-200">{profile.phoneNumber}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Emergency Contact */}
          {(profile.emergencyContact || profile.emergencyPhone) && (
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">Emergency Contact</h2>
              
              <div className="grid grid-cols-1 gap-4">
                {profile.emergencyContact && (
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Contact Name</p>
                    <p className="font-semibold text-gray-800 dark:text-gray-200">{profile.emergencyContact}</p>
                  </div>
                )}
                
                {profile.emergencyPhone && (
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Contact Phone</p>
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 text-red-500 mr-1" />
                      <p className="font-semibold text-gray-800 dark:text-gray-200">{profile.emergencyPhone}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Medical Sections */}
          <div className="p-6">
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">Medical Information</h2>
            
            {/* Allergies */}
            <div className="mb-6">
              <div className="flex items-center mb-2">
                <AlertTriangleIcon className="h-5 w-5 text-red-500 mr-2" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Allergies</h3>
              </div>
              
              {profile.allergies ? (
                <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-md">
                  <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">{profile.allergies}</p>
                </div>
              ) : (
                <p className="text-gray-500 dark:text-gray-400 italic">No allergies specified or information is private</p>
              )}
            </div>
            
            {/* Medications */}
            <div className="mb-6">
              <div className="flex items-center mb-2">
                <PillIcon className="h-5 w-5 text-blue-500 mr-2" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Medications</h3>
              </div>
              
              {profile.medications ? (
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
                  <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">{profile.medications}</p>
                </div>
              ) : (
                <p className="text-gray-500 dark:text-gray-400 italic">No medications specified or information is private</p>
              )}
            </div>
            
            {/* Medical Conditions */}
            <div className="mb-6">
              <div className="flex items-center mb-2">
                <Heart className="h-5 w-5 text-medical-primary dark:text-medical-accent mr-2" />
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Medical Conditions</h3>
              </div>
              
              {profile.conditions ? (
                <div className="bg-medical-light dark:bg-medical-primary/20 p-4 rounded-md">
                  <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">{profile.conditions}</p>
                </div>
              ) : (
                <p className="text-gray-500 dark:text-gray-400 italic">No conditions specified or information is private</p>
              )}
            </div>
            
            {/* Organ Donor */}
            {profile.showOrganDonor && (
              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <Heart className="h-5 w-5 text-red-500 mr-2" />
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Organ Donor Status</h3>
                </div>
                
                <div className="flex items-center">
                  {profile.organDonor ? (
                    <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-md flex items-center">
                      <BadgeCheck className="h-5 w-5 text-green-500 mr-2" />
                      <p className="text-gray-800 dark:text-gray-200">Registered Organ Donor</p>
                    </div>
                  ) : (
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md flex items-center">
                      <XCircle className="h-5 w-5 text-gray-400 mr-2" />
                      <p className="text-gray-500 dark:text-gray-400">Not registered as an organ donor</p>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {/* Vaccinations */}
            {profile.vaccinations && profile.showVaccinations && (
              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <Syringe className="h-5 w-5 text-medical-primary dark:text-medical-accent mr-2" />
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Vaccination History</h3>
                </div>
                
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-md">
                  <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">{profile.vaccinations}</p>
                </div>
              </div>
            )}
            
            {/* Doctor Info */}
            {(profile.doctorName || profile.doctorPhone) && profile.showDoctorInfo && (
              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <User className="h-5 w-5 text-blue-500 mr-2" />
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Primary Doctor</h3>
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-md">
                  {profile.doctorName && (
                    <p className="text-gray-800 dark:text-gray-200">
                      <span className="font-medium">Name:</span> {profile.doctorName}
                    </p>
                  )}
                  
                  {profile.doctorPhone && (
                    <p className="text-gray-800 dark:text-gray-200 mt-1">
                      <span className="font-medium">Phone:</span> {profile.doctorPhone}
                    </p>
                  )}
                </div>
              </div>
            )}
            
            {/* Mental Health */}
            {profile.mentalHealthConditions && profile.showMentalHealth && (
              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <Brain className="h-5 w-5 text-purple-500 mr-2" />
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Mental Health Conditions</h3>
                </div>
                
                <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-md">
                  <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">{profile.mentalHealthConditions}</p>
                </div>
              </div>
            )}
            
            {/* Insurance Info */}
            {(profile.insurerName || profile.policyNumber) && profile.showInsurance && (
              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <Activity className="h-5 w-5 text-green-500 mr-2" />
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Health Insurance</h3>
                </div>
                
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-md">
                  {profile.insurerName && (
                    <p className="text-gray-800 dark:text-gray-200">
                      <span className="font-medium">Provider:</span> {profile.insurerName}
                    </p>
                  )}
                  
                  {profile.policyNumber && (
                    <p className="text-gray-800 dark:text-gray-200 mt-1">
                      <span className="font-medium">Policy Number:</span> {profile.policyNumber}
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
          
          {/* Last Updated */}
          {profile.updatedAt && (
            <div className="p-4 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-200 dark:border-gray-700 text-center">
              <div className="flex items-center justify-center text-sm text-gray-500 dark:text-gray-400">
                <Clock className="h-4 w-4 mr-1" />
                <span>
                  Last updated: {new Date(profile.updatedAt.toDate()).toLocaleDateString()}
                </span>
              </div>
            </div>
          )}
        </div>
        
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            For emergency use only. Please respect patient privacy.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PublicProfile;
