
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Navbar from '../components/Navbar';
import { createUserProfile, getUserProfile } from '../utils/firebase';
import { useToast } from "@/hooks/use-toast";
import { useTheme } from '../context/ThemeContext';
import { Save, AlertCircle, Info, Mail, Phone, Heart, Activity, Syringe, User, Brain } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Form, FormField, FormItem, FormLabel, FormControl, FormDescription } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";

const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'];

const ProfileForm: React.FC = () => {
  const { currentUser } = useAuth();
  const { isDarkMode } = useTheme();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Form fields
  const [fullName, setFullName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [age, setAge] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');
  const [allergies, setAllergies] = useState('');
  const [medications, setMedications] = useState('');
  const [conditions, setConditions] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [emergencyContact, setEmergencyContact] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [familyContact, setFamilyContact] = useState('');
  const [organDonor, setOrganDonor] = useState(false);
  const [insurerName, setInsurerName] = useState('');
  const [policyNumber, setPolicyNumber] = useState('');
  const [vaccinations, setVaccinations] = useState('');
  const [doctorName, setDoctorName] = useState('');
  const [doctorPhone, setDoctorPhone] = useState('');
  const [mentalHealthConditions, setMentalHealthConditions] = useState('');
  
  // Privacy toggles
  const [showAllergies, setShowAllergies] = useState(true);
  const [showMedications, setShowMedications] = useState(true);
  const [showConditions, setShowConditions] = useState(true);
  const [showOrganDonor, setShowOrganDonor] = useState(true);
  const [showInsurance, setShowInsurance] = useState(false);
  const [showVaccinations, setShowVaccinations] = useState(true);
  const [showDoctorInfo, setShowDoctorInfo] = useState(true);
  const [showMentalHealth, setShowMentalHealth] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [formLoading, setFormLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      if (currentUser) {
        try {
          const profileData = await getUserProfile(currentUser.uid);
          if (profileData) {
            // Fill form with existing data
            setFullName(profileData.fullName || '');
            setDateOfBirth(profileData.dateOfBirth || '');
            setAge(profileData.age || '');
            setBloodGroup(profileData.bloodGroup || '');
            setAllergies(profileData.allergies || '');
            setMedications(profileData.medications || '');
            setConditions(profileData.conditions || '');
            setEmail(profileData.email || currentUser.email || '');
            setPhoneNumber(profileData.phoneNumber || '');
            setEmergencyContact(profileData.emergencyContact || '');
            setEmergencyPhone(profileData.emergencyPhone || '');
            setFamilyContact(profileData.familyContact || '');
            setOrganDonor(profileData.organDonor || false);
            setInsurerName(profileData.insurerName || '');
            setPolicyNumber(profileData.policyNumber || '');
            setVaccinations(profileData.vaccinations || '');
            setDoctorName(profileData.doctorName || '');
            setDoctorPhone(profileData.doctorPhone || '');
            setMentalHealthConditions(profileData.mentalHealthConditions || '');
            
            // Set privacy toggles
            setShowAllergies(profileData.showAllergies !== false);
            setShowMedications(profileData.showMedications !== false);
            setShowConditions(profileData.showConditions !== false);
            setShowOrganDonor(profileData.showOrganDonor !== false);
            setShowInsurance(profileData.showInsurance || false);
            setShowVaccinations(profileData.showVaccinations !== false);
            setShowDoctorInfo(profileData.showDoctorInfo !== false);
            setShowMentalHealth(profileData.showMentalHealth || false);
          }
        } catch (error) {
          console.error('Error fetching profile:', error);
          setError('Failed to load profile data');
        } finally {
          setFormLoading(false);
        }
      }
    };

    fetchProfile();
  }, [currentUser]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      setError('You must be logged in');
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      // Create/update user profile in Firestore
      await createUserProfile(currentUser.uid, {
        fullName,
        dateOfBirth,
        age,
        bloodGroup,
        allergies,
        medications,
        conditions,
        email,
        phoneNumber,
        emergencyContact,
        emergencyPhone,
        familyContact,
        organDonor,
        insurerName,
        policyNumber,
        vaccinations,
        doctorName,
        doctorPhone,
        mentalHealthConditions,
        showAllergies,
        showMedications,
        showConditions,
        showOrganDonor,
        showInsurance,
        showVaccinations,
        showDoctorInfo,
        showMentalHealth,
        profileCompleted: true,
        profileStarted: true,
        updatedAt: new Date(),
      });
      
      toast({
        title: "Profile Saved!",
        description: "Your medical profile has been updated.",
      });
      
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Profile update error:', error);
      setError(error.message || 'Failed to update profile');
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || 'Failed to update profile',
      });
    } finally {
      setLoading(false);
    }
  };

  if (formLoading) {
    return (
      <div className="min-h-screen flex flex-col dark:bg-gray-900">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <div className="rounded-md h-12 w-12 border-4 border-t-medical-primary border-r-transparent border-b-transparent border-l-transparent animate-spin"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-medical-light dark:bg-gray-900 transition-colors duration-200">
      <Navbar />
      
      <div className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-6">Medical Profile</h1>
          
          <div className="bg-blue-50 dark:bg-blue-900/30 border-l-4 border-medical-primary p-4 mb-6">
            <div className="flex">
              <div className="flex-shrink-0">
                <Info className="h-5 w-5 text-medical-primary dark:text-blue-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  This information will be used to create your emergency medical profile. 
                  Fields marked with privacy toggles let you control what appears on your public profile.
                </p>
              </div>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/30 border-l-4 border-red-500 p-4 mb-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700 dark:text-red-300">{error}</p>
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            {/* Personal Information */}
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Personal Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="fullName" className="text-gray-700 dark:text-gray-300">Full Name</Label>
                  <Input
                    id="fullName"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="John Doe"
                  />
                </div>
                
                <div>
                  <Label htmlFor="dateOfBirth" className="text-gray-700 dark:text-gray-300">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    required
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                  />
                </div>

                <div>
                  <Label htmlFor="age" className="text-gray-700 dark:text-gray-300">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="32"
                  />
                </div>
                
                <div>
                  <Label htmlFor="bloodGroup" className="text-gray-700 dark:text-gray-300">Blood Group</Label>
                  <select
                    id="bloodGroup"
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    required
                    className="w-full rounded-md border border-input bg-white dark:bg-gray-700 dark:text-gray-100 px-3 py-2"
                  >
                    <option value="">Select Blood Group</option>
                    {bloodGroups.map((group) => (
                      <option key={group} value={group}>{group}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            
            {/* Contact Information */}
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4 flex items-center">
                <Mail className="mr-2 h-5 w-5 text-medical-primary dark:text-medical-accent" />
                Contact Information
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="johndoe@example.com"
                  />
                </div>
                
                <div>
                  <Label htmlFor="phoneNumber" className="text-gray-700 dark:text-gray-300">Phone Number</Label>
                  <Input
                    id="phoneNumber"
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="(123) 456-7890"
                  />
                </div>
                
                <div>
                  <Label htmlFor="familyContact" className="text-gray-700 dark:text-gray-300">Family Contact (Optional)</Label>
                  <Input
                    id="familyContact"
                    type="tel"
                    value={familyContact}
                    onChange={(e) => setFamilyContact(e.target.value)}
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="(123) 456-7890"
                  />
                </div>
              </div>
            </div>
            
            {/* Medical Information */}
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Medical Information</h2>
              
              <div className="mb-4">
                <div className="flex justify-between items-center">
                  <Label htmlFor="allergies" className="text-gray-700 dark:text-gray-300">Allergies</Label>
                  <div className="flex items-center">
                    <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">Show publicly</span>
                    <Switch
                      checked={showAllergies}
                      onCheckedChange={setShowAllergies}
                    />
                  </div>
                </div>
                <Textarea
                  id="allergies"
                  value={allergies}
                  onChange={(e) => setAllergies(e.target.value)}
                  className="h-24 bg-white dark:bg-gray-700 dark:text-gray-100"
                  placeholder="List any allergies (e.g., penicillin, peanuts, latex)"
                />
              </div>
              
              <div className="mb-4">
                <div className="flex justify-between items-center">
                  <Label htmlFor="medications" className="text-gray-700 dark:text-gray-300">Current Medications</Label>
                  <div className="flex items-center">
                    <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">Show publicly</span>
                    <Switch
                      checked={showMedications}
                      onCheckedChange={setShowMedications}
                    />
                  </div>
                </div>
                <Textarea
                  id="medications"
                  value={medications}
                  onChange={(e) => setMedications(e.target.value)}
                  className="h-24 bg-white dark:bg-gray-700 dark:text-gray-100"
                  placeholder="List any medications you are currently taking (e.g., insulin, aspirin)"
                />
              </div>
              
              <div className="mb-4">
                <div className="flex justify-between items-center">
                  <Label htmlFor="conditions" className="text-gray-700 dark:text-gray-300">Medical Conditions</Label>
                  <div className="flex items-center">
                    <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">Show publicly</span>
                    <Switch
                      checked={showConditions}
                      onCheckedChange={setShowConditions}
                    />
                  </div>
                </div>
                <Textarea
                  id="conditions"
                  value={conditions}
                  onChange={(e) => setConditions(e.target.value)}
                  className="h-24 bg-white dark:bg-gray-700 dark:text-gray-100"
                  placeholder="List any medical conditions (e.g., diabetes, asthma, heart disease)"
                />
              </div>
              
              {/* Organ Donor Status */}
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center">
                    <Heart className="h-5 w-5 text-red-500 mr-2" />
                    <Label htmlFor="organDonor" className="text-gray-700 dark:text-gray-300">Organ Donor Status</Label>
                  </div>
                  <div className="flex items-center">
                    <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">Show publicly</span>
                    <Switch
                      checked={showOrganDonor}
                      onCheckedChange={setShowOrganDonor}
                    />
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="organDonor" 
                    checked={organDonor}
                    onCheckedChange={(checked) => setOrganDonor(checked === true)}
                  />
                  <label
                    htmlFor="organDonor"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-gray-700 dark:text-gray-300"
                  >
                    I am registered as an organ donor
                  </label>
                </div>
              </div>
              
              {/* Vaccination History */}
              <div className="mb-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Syringe className="h-5 w-5 text-medical-primary mr-2" />
                    <Label htmlFor="vaccinations" className="text-gray-700 dark:text-gray-300">Vaccination History</Label>
                  </div>
                  <div className="flex items-center">
                    <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">Show publicly</span>
                    <Switch
                      checked={showVaccinations}
                      onCheckedChange={setShowVaccinations}
                    />
                  </div>
                </div>
                <Textarea
                  id="vaccinations"
                  value={vaccinations}
                  onChange={(e) => setVaccinations(e.target.value)}
                  className="h-24 bg-white dark:bg-gray-700 dark:text-gray-100"
                  placeholder="List your vaccination history (e.g., COVID-19, Tetanus, Flu)"
                />
              </div>
              
              {/* Mental Health Conditions */}
              <div className="mb-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Brain className="h-5 w-5 text-purple-500 mr-2" />
                    <Label htmlFor="mentalHealthConditions" className="text-gray-700 dark:text-gray-300">Mental Health Conditions (Optional)</Label>
                  </div>
                  <div className="flex items-center">
                    <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">Show publicly</span>
                    <Switch
                      checked={showMentalHealth}
                      onCheckedChange={setShowMentalHealth}
                    />
                  </div>
                </div>
                <Textarea
                  id="mentalHealthConditions"
                  value={mentalHealthConditions}
                  onChange={(e) => setMentalHealthConditions(e.target.value)}
                  className="h-24 bg-white dark:bg-gray-700 dark:text-gray-100"
                  placeholder="List any mental health conditions if relevant (e.g., anxiety, depression)"
                />
              </div>
            </div>
            
            {/* Health Insurance Info */}
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4 flex items-center">
                <Activity className="mr-2 h-5 w-5 text-green-500" />
                Health Insurance Information (Optional)
              </h2>
              
              <div className="flex justify-end mb-2">
                <div className="flex items-center">
                  <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">Show publicly</span>
                  <Switch
                    checked={showInsurance}
                    onCheckedChange={setShowInsurance}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="insurerName" className="text-gray-700 dark:text-gray-300">Insurance Provider</Label>
                  <Input
                    id="insurerName"
                    type="text"
                    value={insurerName}
                    onChange={(e) => setInsurerName(e.target.value)}
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="Insurance Company Name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="policyNumber" className="text-gray-700 dark:text-gray-300">Policy Number</Label>
                  <Input
                    id="policyNumber"
                    type="text"
                    value={policyNumber}
                    onChange={(e) => setPolicyNumber(e.target.value)}
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="Policy/Member ID"
                  />
                </div>
              </div>
            </div>
            
            {/* Primary Doctor Info */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4 flex items-center">
                <User className="mr-2 h-5 w-5 text-blue-500" />
                Primary Doctor Information
              </h2>
              
              <div className="flex justify-end mb-2">
                <div className="flex items-center">
                  <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">Show publicly</span>
                  <Switch
                    checked={showDoctorInfo}
                    onCheckedChange={setShowDoctorInfo}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="doctorName" className="text-gray-700 dark:text-gray-300">Doctor's Name</Label>
                  <Input
                    id="doctorName"
                    type="text"
                    value={doctorName}
                    onChange={(e) => setDoctorName(e.target.value)}
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="Dr. Jane Smith"
                  />
                </div>
                
                <div>
                  <Label htmlFor="doctorPhone" className="text-gray-700 dark:text-gray-300">Doctor's Phone</Label>
                  <Input
                    id="doctorPhone"
                    type="tel"
                    value={doctorPhone}
                    onChange={(e) => setDoctorPhone(e.target.value)}
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="(123) 456-7890"
                  />
                </div>
              </div>
            </div>
            
            {/* Emergency Contact */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4 flex items-center">
                <Phone className="mr-2 h-5 w-5 text-red-500" />
                Emergency Contact
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="emergencyContact" className="text-gray-700 dark:text-gray-300">Emergency Contact Name</Label>
                  <Input
                    id="emergencyContact"
                    type="text"
                    value={emergencyContact}
                    onChange={(e) => setEmergencyContact(e.target.value)}
                    required
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="Jane Doe"
                  />
                </div>
                
                <div>
                  <Label htmlFor="emergencyPhone" className="text-gray-700 dark:text-gray-300">Emergency Contact Phone</Label>
                  <Input
                    id="emergencyPhone"
                    type="tel"
                    value={emergencyPhone}
                    onChange={(e) => setEmergencyPhone(e.target.value)}
                    required
                    className="bg-white dark:bg-gray-700 dark:text-gray-100"
                    placeholder="(123) 456-7890"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={loading}
                className="bg-medical-primary hover:bg-medical-secondary text-white font-medium py-2 px-6 rounded-md transition duration-300 flex items-center dark:bg-medical-secondary dark:hover:bg-medical-primary"
              >
                {loading ? (
                  <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                ) : (
                  <Save className="h-5 w-5 mr-2" />
                )}
                Save Profile
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProfileForm;
