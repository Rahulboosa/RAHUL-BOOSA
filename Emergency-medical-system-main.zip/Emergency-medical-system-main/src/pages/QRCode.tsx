
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { useAuth } from '../context/AuthContext';
import Navbar from '../components/Navbar';
import { createUserProfile, createPublicProfile, getUserProfile } from '../utils/firebase';
import { generatePublicId, generateQRCodeUrl, downloadQRCode } from '../utils/qrCodeGenerator';
import { useToast } from "@/hooks/use-toast";
import { Download, Share, ArrowLeft, Info, Clipboard, CheckCircle, AlertCircle } from 'lucide-react';

const QRCode: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [publicId, setPublicId] = useState<string | null>(null);
  const [profileData, setProfileData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [qrUrl, setQrUrl] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      if (currentUser) {
        try {
          const profile = await getUserProfile(currentUser.uid);
          setProfileData(profile);
          
          if (profile?.publicId) {
            setPublicId(profile.publicId);
            setQrUrl(generateQRCodeUrl(profile.publicId));
          }
        } catch (error) {
          console.error('Error fetching profile:', error);
          setError('Failed to load profile data');
        } finally {
          setLoading(false);
        }
      }
    };

    fetchProfile();
  }, [currentUser]);

  const createNewQrCode = async () => {
    if (!currentUser || !profileData) {
      setError('Profile data not available');
      return;
    }
    
    if (!profileData.profileCompleted) {
      setError('Please complete your profile first');
      navigate('/profile-form');
      return;
    }
    
    setGenerating(true);
    setError('');

    try {
      // Generate a new public ID
      const newPublicId = generatePublicId();
      
      // Create public profile data
      const publicProfileData = {
        name: profileData.fullName,
        bloodGroup: profileData.bloodGroup,
        dateOfBirth: profileData.dateOfBirth,
        allergies: profileData.showAllergies ? profileData.allergies : null,
        medications: profileData.showMedications ? profileData.medications : null,
        conditions: profileData.showConditions ? profileData.conditions : null,
        updatedAt: new Date(),
      };
      
      // Create public profile document
      await createPublicProfile(newPublicId, publicProfileData);
      
      // Update user profile with public ID
      await createUserProfile(currentUser.uid, {
        ...profileData,
        publicId: newPublicId,
        updatedAt: new Date(),
      });
      
      setPublicId(newPublicId);
      setQrUrl(generateQRCodeUrl(newPublicId));
      
      toast({
        title: "QR Code Generated!",
        description: "Your emergency QR code is ready to download.",
      });
    } catch (error: any) {
      console.error('QR code generation error:', error);
      setError(error.message || 'Failed to generate QR code');
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || 'Failed to generate QR code',
      });
    } finally {
      setGenerating(false);
    }
  };

  const handleCopyLink = () => {
    if (qrUrl) {
      navigator.clipboard.writeText(qrUrl);
      setCopied(true);
      toast({
        title: "Link Copied!",
        description: "Profile URL copied to clipboard.",
      });
      
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleShare = () => {
    if (navigator.share && qrUrl) {
      navigator.share({
        title: 'My Emergency Medical Profile',
        text: 'Scan this QR code or use this link to access my emergency medical information:',
        url: qrUrl,
      })
      .then(() => console.log('Shared successfully'))
      .catch((error) => console.error('Error sharing:', error));
    } else {
      handleCopyLink();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <div className="rounded-md h-12 w-12 border-4 border-t-medical-primary border-r-transparent border-b-transparent border-l-transparent animate-spin"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center mb-6">
            <button 
              onClick={() => navigate('/dashboard')}
              className="mr-4 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <h1 className="text-3xl font-bold text-gray-800">Emergency QR Code</h1>
          </div>
          
          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-md p-6">
            {publicId ? (
              <div className="text-center">
                <div className="bg-blue-50 border-l-4 border-medical-primary p-4 mb-6 text-left">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Info className="h-5 w-5 text-medical-primary" />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-blue-700">
                        Your emergency QR code is ready. Print it, save it to your phone, or share the link.
                        Anyone who scans this code will be able to view your public medical information.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mb-6 p-4 inline-block bg-white rounded-lg shadow-md">
                  <QRCodeSVG
                    id="qr-code"
                    value={qrUrl}
                    size={200}
                    bgColor={"#ffffff"}
                    fgColor={"#000000"}
                    level={"H"}
                    includeMargin={true}
                  />
                </div>
                
                <p className="text-gray-700 mb-6">
                  This QR code links to your public medical profile.
                </p>
                
                <div className="flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-4">
                  <button
                    onClick={downloadQRCode}
                    className="bg-medical-primary hover:bg-medical-secondary text-white font-medium py-2 px-4 rounded-md transition duration-300 flex items-center justify-center"
                  >
                    <Download className="h-5 w-5 mr-2" />
                    Download QR
                  </button>
                  
                  <button
                    onClick={handleShare}
                    className="bg-white hover:bg-gray-100 text-medical-primary font-medium py-2 px-4 rounded-md border border-medical-primary transition duration-300 flex items-center justify-center"
                  >
                    <Share className="h-5 w-5 mr-2" />
                    Share Profile
                  </button>
                </div>
                
                <div className="mt-8 pt-6 border-t border-gray-200">
                  <p className="text-gray-700 mb-2">Profile URL:</p>
                  <div className="flex items-center justify-center">
                    <input
                      type="text"
                      value={qrUrl}
                      readOnly
                      className="medical-input text-sm mr-2 bg-gray-50"
                    />
                    <button
                      onClick={handleCopyLink}
                      className="bg-gray-100 hover:bg-gray-200 p-2 rounded-md"
                      title="Copy to clipboard"
                    >
                      {copied ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <Clipboard className="h-5 w-5 text-gray-600" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center">
                <div className="bg-blue-50 border-l-4 border-medical-primary p-4 mb-6 text-left">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Info className="h-5 w-5 text-medical-primary" />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-blue-700">
                        Generate a QR code for your emergency medical profile. When scanned, this QR code will 
                        provide access to your essential medical information for first responders.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="p-6 mb-6">
                  <div className="w-32 h-32 mx-auto border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                    <QRCodeSVG 
                      value=""
                      size={100}
                      bgColor={"#ffffff"}
                      fgColor={"#cccccc"}
                      level={"H"}
                      includeMargin={true}
                    />
                  </div>
                </div>
                
                <p className="text-gray-700 mb-6">
                  {profileData?.profileCompleted ? 
                    "Your profile is complete. Generate your emergency QR code now." : 
                    "Complete your profile first to generate a QR code."}
                </p>
                
                <button
                  onClick={createNewQrCode}
                  disabled={generating || !profileData?.profileCompleted}
                  className={`font-medium py-2 px-6 rounded-md transition duration-300 flex items-center justify-center mx-auto
                    ${profileData?.profileCompleted ? 
                      "bg-medical-primary hover:bg-medical-secondary text-white" : 
                      "bg-gray-200 text-gray-500 cursor-not-allowed"}`}
                >
                  {generating ? (
                    <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  ) : (
                    <QRCodeSVG className="h-5 w-5 mr-2" value="" size={20} />
                  )}
                  Generate QR Code
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default QRCode;
