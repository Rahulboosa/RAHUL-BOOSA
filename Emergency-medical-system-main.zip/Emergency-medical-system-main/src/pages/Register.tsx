
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { signInWithGoogle } from '../utils/firebase';
import Navbar from '../components/Navbar';
import { AlertCircle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";

const Register: React.FC = () => {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleGoogleSignIn = async () => {
    setError('');
    setLoading(true);

    try {
      await signInWithGoogle();
      toast({
        title: "Account created!",
        description: "You have successfully registered.",
      });
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Registration error:', error);
      setError(error.message || 'Failed to create account');
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || 'Failed to create account',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="flex-grow flex items-center justify-center bg-medical-light">
        <div className="max-w-md w-full mx-4">
          <div className="bg-white p-8 rounded-lg shadow-md">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800">Create Account</h2>
              <p className="text-gray-600 mt-2">Sign up to create your MediQR profile</p>
            </div>

            {error && (
              <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-red-500" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="mb-6">
              <Button
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="w-full bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 font-medium py-2 px-4 rounded-md transition duration-300 flex justify-center items-center space-x-2"
                variant="outline"
                size="lg"
              >
                {loading ? (
                  <div className="h-5 w-5 border-2 border-gray-600 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <svg className="w-5 h-5" viewBox="0 0 24 24">
                      <path fill="#EA4335" d="M12 5.9c1.6 0 3 .6 4.1 1.4l3-3C17 2.4 14.7 1 12 1 7.6 1 3.9 3.6 2.1 7.2l3.5 2.7C6.7 7.2 9.1 5.9 12 5.9z"></path>
                      <path fill="#34A853" d="M12 22c2.7 0 5-1 6.7-2.6l-3.2-2.6c-.9.6-2 1-3.5 1-2.7 0-5-1.6-6-3.8H2.3C4 18.2 7.7 22 12 22z"></path>
                      <path fill="#FBBC05" d="M6 13.6C5.7 12.8 5.5 11.9 5.5 11s.2-1.8.5-2.6V5.8H2.3C1.5 7.4 1 9.1 1 11s.5 3.6 1.3 5.2L6 13.6z"></path>
                      <path fill="#4285F4" d="M12 5.9c1.6 0 3 .6 4.1 1.4l3-3C17 2.4 14.7 1 12 1 7.6 1 3.9 3.6 2.1 7.2l3.5 2.7C6.7 7.2 9.1 5.9 12 5.9z"></path>
                      <path fill="#4285F4" d="M23 11c0-.7-.1-1.3-.2-1.8H12v3.8h6.3c-.3 1.6-1.1 2.9-2.3 3.6l3.2 2.6C21.5 17.5 23 14.5 23 11z"></path>
                    </svg>
                    <span>Sign up with Google</span>
                  </>
                )}
              </Button>
            </div>

            <div className="text-center">
              <p className="text-sm text-gray-600">
                Already have an account?{' '}
                <Link to="/login" className="text-medical-primary hover:underline font-medium">
                  Sign in
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
